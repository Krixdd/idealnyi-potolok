document.addEventListener("DOMContentLoaded", () => {
  const $ = id => document.getElementById(id);
  const money = n => n.toLocaleString("ru-RU") + " ₸";

  // КАЛЬКУЛЯТОР
  $("go").addEventListener("click", () => {
    const area = Number($("area").value);
    const material = Number($("material").value);
    const sofits = Number($("sofits").value) || 0;
    const lines = Number($("lines").value) || 0;
    const result = $("result");

    if (!Number.isFinite(area) || area <= 0) {
      result.innerHTML = '<div class="result-details"><span>Расчёт стоимости</span><p>Введите площадь помещения.</p></div><b>—</b>';
      $("area").focus();
      return;
    }

    const ceilingPrice = area * material;
    const sofitPrice = sofits * 4000;
    const linePrice = lines * 18000;
    const total = ceilingPrice + sofitPrice + linePrice;

    result.innerHTML = `<div class="result-details"><span>Расчёт стоимости</span><p>Потолок: ${money(ceilingPrice)}</p><p>Софиты: ${money(sofitPrice)}</p><p>Световые линии: ${money(linePrice)}</p></div><b>Итого: ${money(total)}</b>`;
  });

  // ДАННЫЕ ФОТОГАЛЕРЕЙ. Первое фото берётся прямо из карточки.
  const extraPhotos = {
    "Матовый потолок": [
      "https://tver.tmk-potolok.ru/upload/dev2fun.imagecompress/webp/iblock/48b/0gxmemof7jg3b4q7c92nmsf0h3kv3s5s.webp",
      "https://s3.stroi-news.ru/img/belii-matovii-potolok-dizain-vkontakte-63.jpg"
    ],
    "Глянцевый потолок": [
      "https://m-stelya.com.ua/image/cache/catalog/image/cache/catalog/221225-600x399.webp",
      "https://polskiled.com.pl/img/13497/G%C5%81%C3%93WNE%206.jpg"
    ],
    "Сатиновый потолок": [
      "https://www.imperialhq.com/uploads/gallery/full5b949efbaa095.jpg",
      "https://www.imperialhq.com/uploads/gallery/full5b94a00089454.jpg"
    ],
    "Софит": [
      "https://static.tildacdn.com/tild6232-6562-4630-a237-656231316134/photo_4_2025-12-01_1.jpg",
      "https://static.tildacdn.com/tild6232-6562-4630-a237-656231316134/photo_4_2025-12-01_1.jpg"
    ],
    "Световая линия": [
      "https://www.antonangeli.it/public/easynet4/images/copertina_eq2m16jxsf.jpg",
      "https://www.antonangeli.it/public/easynet4/images/copertina_eq2m16jxsf.jpg"
    ],
    "Магнитные треки": [
      "https://kadilux.com/storage/uploads/images/Mr%20Chi%E1%BA%BFn/bo-tri-den-ray-nam-cham-phong-khach-3.jpg",
      "https://elektrovoz.com.ua/files/resized/products/5b7996aece2e93add600e240cb66b7ae_5.600x800.jpg"
    ],
    "Теневой потолок": [
      "https://potoloksmart.ru/image/shadowceiling.jpg",
      "https://bigfoto.name/photo/uploads/posts/2024-03/1710958345_bigfoto-name-eguc-p-potolok-s-tenevim-profilem-19.jpg"
    ],
    "Парящий потолок": [
      "https://stroi-news.ru/wp-content/uploads/2024/02/paryashchij-potolok-v-interere.jpg",
      "https://stroi-news.ru/wp-content/uploads/2024/02/paryashchij-potolok-v-interere.jpg",
      "https://stroi-news.ru/wp-content/uploads/2024/02/paryashchij-potolok-v-interere.jpg"
    ],
    "Гардина ПК14": [
      "https://curtain.lt/assets/articles/karnizu-tipu-palyginimas/01-sviesos-nutekejimas.webp",
      "https://idei.club/raznoe/uploads/posts/2023-05/1685345795_idei-club-p-natyazhnie-potolki-so-vstroennim-karnizom-1.jpg"
    ],
    "Ставки": [
      "https://images.gutefrage.net/media/fragen-antworten/bilder/237360701/0_big.jpg?v=1486109755000",
      "https://images.gutefrage.net/media/fragen-antworten/bilder/237360701/0_big.jpg?v=1486109755000"
    ]
  };

  // МОДАЛЬНОЕ ОКНО ТОВАРА
  const modal = $("productModal");
  const modalImage = $("modalImage");
  const modalTitle = $("modalTitle");
  const modalPrice = $("modalPrice");
  const modalDescription = $("modalDescription");
  const modalWhatsApp = $("modalWhatsApp");
  const dots = $("galleryDots");
  let gallery = [];
  let galleryIndex = 0;

  function showPhoto() {
    if (!gallery.length) return;
    modalImage.src = gallery[galleryIndex];
    dots.innerHTML = gallery.map((_, i) => `<button type="button" class="${i === galleryIndex ? "active" : ""}" aria-label="Фото ${i + 1}"></button>`).join("");
    dots.querySelectorAll("button").forEach((button, i) => {
      button.addEventListener("click", () => { galleryIndex = i; showPhoto(); });
    });
  }

  function openProduct(card) {
    const title = card.querySelector("h3")?.textContent.trim() || "Товар";
    const description = card.querySelector("p")?.textContent.trim() || "Описание товара.";
    const price = card.querySelector("b")?.textContent.trim() || "Цена по запросу";
    const firstPhoto = card.querySelector(".media img")?.getAttribute("src");
    const photos = extraPhotos[title] || [];
    gallery = [firstPhoto, ...photos].filter(Boolean).filter((src, i, arr) => arr.indexOf(src) === i);
    galleryIndex = 0;
    modalTitle.textContent = title;
    modalPrice.textContent = price;
    modalDescription.textContent = description + " Здесь можно посмотреть фотографии, узнать цену и связаться с нами для уточнения деталей и замера.";
    modalWhatsApp.href = "https://wa.me/77787031632?text=" + encodeURIComponent("Здравствуйте! Интересует: " + title + ". Хочу узнать подробности и стоимость.");
    showPhoto();
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  }

  function closeProduct() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  }

  document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("click", event => {
      if (event.target.closest("a")) return;
      openProduct(card);
    });
    card.addEventListener("keydown", event => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openProduct(card);
      }
    });
  });

  document.querySelectorAll("[data-close-modal]").forEach(el => el.addEventListener("click", closeProduct));
  $("modalImage").addEventListener("error", () => {
    // Если внешний сервер фотографии временно недоступен, показываем первое фото карточки.
    const card = [...document.querySelectorAll(".card")].find(c => c.querySelector("h3")?.textContent.trim() === modalTitle.textContent);
    const fallback = card?.querySelector(".media img")?.src;
    if (fallback && modalImage.src !== fallback) modalImage.src = fallback;
  });
  document.querySelector(".gallery-arrow.prev").addEventListener("click", () => {
    if (!gallery.length) return;
    galleryIndex = (galleryIndex - 1 + gallery.length) % gallery.length;
    showPhoto();
  });
  document.querySelector(".gallery-arrow.next").addEventListener("click", () => {
    if (!gallery.length) return;
    galleryIndex = (galleryIndex + 1) % gallery.length;
    showPhoto();
  });
  document.addEventListener("keydown", event => {
    if (!modal.classList.contains("open")) return;
    if (event.key === "Escape") closeProduct();
    if (event.key === "ArrowLeft") $("modalImage").previousElementSibling?.click();
    if (event.key === "ArrowRight") $("modalImage").nextElementSibling?.click();
  });

  // Плавное появление блоков
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
});
